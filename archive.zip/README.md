# EasyVote
EasyVote is a secure mobile voting system accessible through your mobile phone. It aims to be a convenient and cost-effective alternative to paper ballots.

//RUN TEST
1. On your console/terminal redirect to easyvote folder.
2 Install nodemon globally. npm install -g nodemon. 
3. run nodemon server.js. Server should start
4.on web browser redirect to http://localhost:8000 should return "Hello world" .
5. got to /user/list should print an empty/partial list of users.
